# Retrieval & concept-resolution evaluation

Chunks: 143 · gold: draft, **unreviewed** · unit filter: False

| mode | backend | R@1 | R@3 | R@5 | MRR@10 | nDCG@5 | ms/query |
|---|---|---|---|---|---|---|---|
| bm25 | bm25 | 0.646 | 0.877 | 0.954 | 0.771 | 0.791 | 0.35 |
| dense | lsa | 0.585 | 0.831 | 0.908 | 0.72 | 0.728 | 12.6 |
| hybrid | bm25+lsa | 0.585 | 0.877 | 0.954 | 0.742 | 0.771 | 0.76 |

## Held-out: assignment exercises (labels fixed before evaluation)

- Covered exercises, correct lesson card top-1: **0.714** (n=28)
- Uncovered exercises (A5/A6 topics with no lecture deck), tutor declines: **0.889** (n=9)
- Homework guard recall on full exercise text: **0.917** (n=48); false positives on 125 ordinary questions: **0**

Held-out errors:
- A1.E1: expected ['matching'], got `tsp`
- A1.E2: expected ['polynomial_time', 'nearest_neighbor'], got `tsp`
- A1.E5: expected ['cut', 'mst_correctness'], got `mst`
- A3.E1: expected ['shortest_path', 'mst'], got `tree_forest`
- A3.E4: expected ['shortest_path', 'feasible_potential'], got `tree_forest`
- A3.E5: expected ['ford_algorithm'], got `negative_cycle`
- A4.E6: expected ['maxflow_mincut', 'cut_capacity'], got `feasible_potential`
- A5.E5: expected decline (not covered), got `matching`
- A6.E6: expected ['nearest_neighbor'], got `tsp`

Concept resolution top-1 accuracy (dev set, used while tuning): **0.933** (n=60)

Errors:
- `why do kruskal and prim always give an optimal tree` → expected `mst_correctness`, got `prim`
- `how do you find shortest paths with negative costs` → expected `ford_bellman`, got `shortest_path`
- `why does kruskal never pick an edge that closes a cycle` → expected `kruskal`, got `graph_basics`
- `why can a cut bound the flow` → expected `cut_capacity`, got `flow`
